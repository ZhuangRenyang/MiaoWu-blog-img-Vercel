"""
轻量级本地向量知识库
- 不依赖外部数据库：向量存 numpy 文件、元数据存 JSON
- 支持中文友好切分（按语义符号边界，带重叠）
- 余弦相似度检索
生产环境可平滑替换为 Qdrant/Milvus，接口保持一致即可。
"""
import json
import os
import re

import numpy as np

STORE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
INDEX_PATH = os.path.join(STORE_DIR, "kb_index.npz")
META_PATH = os.path.join(STORE_DIR, "kb_meta.json")


def chunk_text(text: str, size: int = 280, overlap: int = 60) -> list[str]:
    """按长度切分，并在标点/换行边界尽量断开，保留 overlap 重叠。"""
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    if len(text) <= size:
        return [text] if text else []

    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            # 在窗口后 1/3 内寻找语义边界
            window = text[start + size // 2 : end]
            for sep in ["\n\n", "。", "！", "？", "；", "\n", "，"]:
                pos = window.rfind(sep)
                if pos != -1:
                    end = start + size // 2 + pos + len(sep)
                    break
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break  # 已覆盖到结尾，防止 start 以 1 字符步进死循环产生大量碎块
        start = max(end - overlap, start + 1)  # 防死循环
    return chunks


class VectorStore:
    def __init__(self):
        os.makedirs(STORE_DIR, exist_ok=True)
        self.vectors = None      # ndarray (n, dim)
        self.meta = []           # [{"doc_id","name","chunk_id","text"}]

    # ---------- 持久化 ----------
    def load(self) -> bool:
        if os.path.exists(INDEX_PATH) and os.path.exists(META_PATH):
            data = np.load(INDEX_PATH)
            self.vectors = data["vectors"]
            with open(META_PATH, encoding="utf-8") as f:
                self.meta = json.load(f)
            return True
        return False

    def save(self):
        if self.vectors is not None:
            np.savez_compressed(INDEX_PATH, vectors=self.vectors)
        with open(META_PATH, "w", encoding="utf-8") as f:
            json.dump(self.meta, f, ensure_ascii=False)

    # ---------- 操作 ----------
    @property
    def count(self) -> int:
        return 0 if self.vectors is None else len(self.vectors)

    def add(self, doc_name: str, chunks: list[str], vectors: list[list[float]]) -> int:
        new_vec = np.array(vectors, dtype=np.float32)
        self.vectors = new_vec if self.vectors is None else np.vstack([self.vectors, new_vec])
        base = max((m["doc_id"] for m in self.meta), default=0) + 1
        for i, c in enumerate(chunks):
            self.meta.append({"doc_id": base, "name": doc_name, "chunk_id": i, "text": c})
        self.save()
        return len(chunks)

    def search(self, query_vec: list[float], top_k: int = 4) -> list[dict]:
        if self.count == 0:
            return []
        q = np.array(query_vec, dtype=np.float32)
        scores = self.vectors @ q / (
            np.linalg.norm(self.vectors, axis=1) * np.linalg.norm(q) + 1e-9
        )
        top = np.argsort(scores)[::-1][:top_k]
        hits = []
        for i in top:
            if scores[i] < 0.45:  # 相似度过低的丢弃（防弱相关上下文诱发幻觉）
                continue
            m = dict(self.meta[i])
            m["score"] = round(float(scores[i]), 4)
            hits.append(m)
        return hits

    def clear(self):
        self.vectors = None
        self.meta = []
        for p in (INDEX_PATH, META_PATH):
            if os.path.exists(p):
                os.remove(p)
