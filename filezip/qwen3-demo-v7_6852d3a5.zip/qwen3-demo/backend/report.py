"""
设备健康日报模块（融合进 qwen3-demo）
链路：传感器 CSV → 清洗 → 双规则异常检测 → 汇总 24h 指标
     → 检索设备手册处置建议 → 大模型生成自然语言日报
"""
import json
import os

import numpy as np
import pandas as pd

# 数据文件默认放在 qwen3-demo/data/ 下，可用环境变量覆盖
DATA_CSV = os.getenv("EQUIPMENT_CSV",
                     os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "equipment_data.csv"))
MANUAL = os.getenv("EQUIPMENT_MANUAL",
                   os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "设备手册.txt"))

WINDOW, SIGMA = 48, 3.0
THRESH = {"vib_high": 4.5, "temp_high": 75.0}

LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
MODEL = os.getenv("QWEN_MODEL", "qwen-turbo")


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.drop_duplicates()
    for col in ["temperature", "vibration", "current"]:
        df.loc[df[col] == 0, col] = np.nan
    df = df.sort_values(["machine_id", "timestamp"])
    for col in ["temperature", "vibration", "current"]:
        df[col] = df.groupby("machine_id")[col].transform(
            lambda s: s.interpolate(limit_direction="both").fillna(s.median())
        )
    return df


def _detect(df: pd.DataFrame) -> pd.DataFrame:
    def rolling_sigma(g: pd.DataFrame) -> pd.DataFrame:
        for col in ["temperature", "vibration"]:
            m = g[col].rolling(WINDOW, min_periods=24).mean()
            s = g[col].rolling(WINDOW, min_periods=24).std()
            g[f"{col}_z"] = ((g[col] - m) / s.replace(0, np.nan)).round(2)
        g["sigma_alert"] = (g["temperature_z"].abs() > SIGMA) | (g["vibration_z"].abs() > SIGMA)
        return g

    df = pd.concat([rolling_sigma(g) for _, g in df.groupby("machine_id")]).sort_index()
    df["rule_alert"] = (df["temperature"] > THRESH["temp_high"]) | (df["vibration"] > THRESH["vib_high"])
    df["alert"] = df["rule_alert"] | df["sigma_alert"]
    return df


def build_summary() -> dict:
    """读取设备数据，完成清洗与检测，汇总最近 24 小时指标。"""
    if not os.path.exists(DATA_CSV):
        return {"error": f"未找到设备数据文件：{DATA_CSV}"}
    df = _detect(_clean(pd.read_csv(DATA_CSV, parse_dates=["timestamp"])))
    latest = df[df["timestamp"] >= df["timestamp"].max() - pd.Timedelta(hours=23)]
    rows = []
    for mid, g in latest.groupby("machine_id"):
        prev = df[(df["machine_id"] == mid) &
                  (df["timestamp"] < df["timestamp"].max() - pd.Timedelta(hours=24))]
        vib_now, vib_prev = g["vibration"].mean(), prev["vibration"].mean()
        item = {
            "设备": mid,
            "平均温度": round(float(g["temperature"].mean()), 1),
            "最高振动": round(float(g["vibration"].max()), 2),
            "振动环比": f"{(vib_now - vib_prev) / vib_prev * 100:+.1f}%",
            "产量": int(g["output_count"].sum()),
            "异常次数": int(g["alert"].sum()),
        }
        if item["异常次数"] >= 8 or item["最高振动"] > THRESH["vib_high"] + 0.8:
            item["风险"] = "高风险"
        elif item["异常次数"] >= 3 or item["最高振动"] > THRESH["vib_high"] - 0.5:
            item["风险"] = "关注"
        else:
            item["风险"] = "正常"
        rows.append(item)
    return {"周期": "最近 24 小时", "设备": rows}


def lookup_manual(keyword: str) -> str:
    """从设备手册中按关键词取处置建议（轻量检索，生产可换 RAG 向量检索）。"""
    if not os.path.exists(MANUAL):
        return ""
    text = open(MANUAL, encoding="utf-8").read()
    for block in text.split("\n\n"):
        if keyword in block:
            return block.strip()[:300]
    return ""


async def generate_report_text(summary: dict) -> str:
    """调用大模型把结构化指标翻译成自然语言日报。"""
    import httpx
    body = json.dumps(summary, ensure_ascii=False, indent=2)
    hints = []
    for m in summary.get("设备", []):
        if m["风险"] != "正常":
            tip = lookup_manual("主轴过热") if m["平均温度"] > 60 else lookup_manual("振动")
            if tip:
                hints.append(f"【{m['设备']}】参考手册建议：{tip}")
    prompt = (
        "你是工厂设备管理员助手。根据以下设备监控数据，写一份给车间主任看的《设备健康日报》。\n"
        "要求：① 先一句话说总体情况；② 高风险设备单独列出问题和建议动作；"
        "③ 语言简洁、面向一线，不要堆砌术语；④ 不超过 300 字。\n\n"
        f"监控数据：\n{body}\n"
        + ("\n参考建议：\n" + "\n".join(hints) if hints else "")
    )
    if not LLM_API_KEY:
        return "（未配置 LLM_API_KEY，以下为结构化数据）\n\n" + body
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(
                f"{LLM_BASE_URL}/chat/completions",
                headers={"Authorization": f"Bearer {LLM_API_KEY}"},
                json={"model": MODEL, "messages": [{"role": "user", "content": prompt}],
                      "enable_thinking": False},
            )
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]
    except Exception as e:
        return f"（模型调用失败：{e}）以下是结构化数据：\n\n{body}"
