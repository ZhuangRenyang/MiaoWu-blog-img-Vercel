# 服务器一键部署脚本（轻量应用服务器 Ubuntu 22.04）
# 使用方法：代码上传到 /opt/qwen3-demo 后，在服务器上执行：
#   LLM_API_KEY=sk-你的百炼Key ACCESS_TOKEN=你的访问令牌 bash deploy.sh

set -e

if [ -z "$LLM_API_KEY" ] || [ -z "$ACCESS_TOKEN" ]; then
  echo "用法: LLM_API_KEY=sk-xxx ACCESS_TOKEN=你的令牌 bash deploy.sh"
  exit 1
fi

if [ "$(id -u)" != "0" ]; then echo "请用 root 执行（sudo bash deploy.sh）"; exit 1; fi
if [ ! -d /opt/qwen3-demo/backend ]; then echo "请先把代码上传到 /opt/qwen3-demo"; exit 1; fi

echo "==> 1/5 安装基础软件"
apt update -y
apt install -y python3-pip nginx curl

echo "==> 2/5 配置 2G swap"
if [ ! -f /swapfile ]; then
  fallocate -l 2G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  grep -q swapfile /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
fi
free -h | grep -i swap || true

echo "==> 3/5 安装后端依赖"
cd /opt/qwen3-demo/backend
pip3 install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple

echo "==> 4/5 配置 systemd 常驻服务"
cat > /etc/systemd/system/qwen-api.service <<EOF
[Unit]
Description=Qwen3 RAG Demo API
After=network.target

[Service]
User=root
WorkingDirectory=/opt/qwen3-demo/backend
Environment=LLM_API_KEY=${LLM_API_KEY}
Environment=QWEN_MODEL=${QWEN_MODEL:-qwen-turbo}
Environment=ACCESS_TOKEN=${ACCESS_TOKEN}
ExecStart=/usr/local/bin/uvicorn main:app --host 127.0.0.1 --port 8000
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now qwen-api

echo "==> 5/5 配置 Nginx（前端 + 反向代理）"
cat > /etc/nginx/sites-available/default <<'EOF'
server {
    listen 80 default_server;
    root /var/www/html;
    index index.html;

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Connection "";
        proxy_buffering off;
        proxy_read_timeout 300s;
    }
}
EOF
cp /opt/qwen3-demo/frontend/index.html /var/www/html/index.html
nginx -t
systemctl reload nginx

sleep 2
echo ""
echo "=========================================="
curl -s http://127.0.0.1:8000/api/health && echo ""
IP=$(curl -s --connect-timeout 3 ifconfig.me || echo 服务器IP)
echo "部署完成！浏览器访问:  http://${IP}/?token=${ACCESS_TOKEN}"
echo "运维命令: systemctl restart qwen-api | journalctl -u qwen-api -f"
echo "=========================================="
