# Qwen3 知识库助手（RAG 版）· 求职作品集项目

网页版通义千问智能助手，带 **RAG 知识库问答**：上传企业文档（txt/md/pdf），助手回答时自动检索相关内容并**标注引用来源**。

```
用户提问 → 问题向量化 → 本地向量库检索 Top4 → 拼入 Prompt → Qwen 流式生成 → 前端打字机效果 + 引用来源
```

## 项目结构

```
qwen3-demo/
├── backend/
│   ├── main.py           # FastAPI：聊天(SSE流式+RAG)、文档上传入库、知识库管理
│   ├── rag_store.py      # 轻量向量库：语义切分、numpy 余弦检索、本地持久化
│   └── requirements.txt
├── frontend/
│   └── index.html        # 聊天界面 + 知识库管理侧栏（拖拽上传、引用来源展示）
└── README.md
```

## 两种运行模式（核心亮点：云端/本地一键切换）

同一套代码支持两种后端，只需改环境变量：

```bash
# 模式 A：云端 API（开发调试，免费额度）
export LLM_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
export LLM_API_KEY=sk-你的Key
export QWEN_MODEL=qwen-turbo
export EMBED_MODEL=text-embedding-v3

# 模式 B：本地 Ollama 私有化（数据不出本机，面试演示用这个）
# 前置：ollama pull qwen3:8b && ollama pull bge-m3
export LLM_BASE_URL=http://localhost:11434/v1
export LLM_API_KEY=ollama
export QWEN_MODEL=qwen3:8b
export EMBED_MODEL=bge-m3
```

> 切换为本地模式后，整个系统（模型、向量库、数据）全部运行在本机，即 JD 中"本地私有化部署"的最小可行实现；换更大显卡环境时把 `LLM_BASE_URL` 指向 vLLM 服务地址即可无缝升级。

## 快速启动（3 步，约 5 分钟）

### 1. 获取 API Key（免费）

1. 注册阿里云并开通「百炼」平台：https://bailian.console.aliyun.com
2. 在「API-KEY 管理」中创建 Key（新用户默认赠送免费额度，含对话模型与 text-embedding 向量模型）

### 2. 启动后端（先选模式，见上节）

```bash
cd backend
pip install -r requirements.txt
export LLM_API_KEY=sk-你的Key        # 云端模式；本地 Ollama 模式见上节
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 3. 打开前端

```bash
cd frontend && python3 -m http.server 5500
# 浏览器访问 http://localhost:5500
```

使用流程：点右上角「📚 知识库」→ 上传文档（支持拖拽）→ 提问 → 回答下方出现 **[1] [2] 引用来源**标签（悬停可看原文片段）。

## 技术要点（面试讲述）

| 问题 | 答案要点 |
|---|---|
| 为什么后端代理而不是前端直连 API？ | 密钥安全（前端零密钥）、统一限流审计、可切换模型供应商 |
| RAG 为什么优于微调灌知识？ | 知识实时可更新、可溯源、无灾难性遗忘；微调解决"表达风格"而非"知识" |
| 检索相关度阈值怎么定？ | 余弦 < 0.3 丢弃，防止"硬凑上下文"导致幻觉 |
| 上下文成本控制？ | 多轮对话滑动窗口（保留最近 10 轮）+ 切分带 overlap、片段截断 |
| 为什么向量库用本地 numpy 而不是 Qdrant？ | 演示规模（万级片段）内 numpy 足够且零依赖；`rag_store.py` 接口化，生产可平滑替换 Qdrant/Milvus |
| SSE 与 WebSocket 取舍？ | 单向流式场景 SSE 更简单、走标准 HTTP、自动重连 |

## 已实现 / 可扩展

- ✅ RAG 全链路：文档解析（txt/md/pdf）→ 语义切分 → 向量化 → 余弦检索 → 带引用生成
- ✅ SSE 流式响应 + 多轮对话记忆
- ✅ 知识库管理：拖拽上传、文档列表、清空；向量持久化（重启不丢）
- ✅ API Key 服务端保管，前端零密钥泄露
- 🔜 混合检索（BM25 + 向量）、Reranker 重排
- 🔜 对话历史存档、多会话管理
- 🔜 Dockerfile + 单元测试 + CI

## 部署到线上（可选）

| 方案 | 说明 | 费用 |
|---|---|---|
| 前端 → Vercel / 免费虚拟主机 | 上传 `index.html`，改 JS 里 `API` 常量为后端地址 | 0 元 |
| 后端 → Fly.io / Render / 国内 1 核 1G 云主机 | `DASHSCOPE_API_KEY` 配为环境变量（后端只转发，不需要 GPU） | 0–10 元/月 |

## 简历表述参考

> 独立开发基于通义千问的企业知识库问答系统：实现 RAG 检索增强（文档解析、语义切分、向量检索、引用溯源）、SSE 流式响应与多轮对话管理，前后端分离架构，已部署上线。
