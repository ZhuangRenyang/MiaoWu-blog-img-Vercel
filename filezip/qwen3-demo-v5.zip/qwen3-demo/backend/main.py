"""
Qwen3 演示项目 - 后端（含 RAG 知识库）
功能：
  1. /api/chat        聊天：自动检索知识库，回答附带引用来源（SSE 流式）
  2. /api/upload      上传文档（txt/md/pdf），自动切分→向量化→入库
  3. /api/kb          查看知识库状态 / 清空
运行：
  # 云端 API 模式
  export LLM_API_KEY=sk-xxxx        # 或沿用旧名 DASHSCOPE_API_KEY
  # 本地 Ollama 模式（真·私有化，面试演示用这个）
  export LLM_BASE_URL=http://localhost:11434/v1 LLM_API_KEY=ollama \
         QWEN_MODEL=qwen3:8b EMBED_MODEL=bge-m3
  uvicorn main:app --host 0.0.0.0 --port 8000
"""
import io
import json
import os
import uuid

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from rag_store import VectorStore, chunk_text

# ---------------- 配置 ----------------
# 支持两种模式（面试加分点：同一套代码，云端 API 与本地私有化部署可切换）
# 模式 A 云端 API：    默认，LLM_BASE_URL 指向 DashScope
# 模式 B 本地私有化：  export LLM_BASE_URL=http://localhost:11434/v1
#                     export QWEN_MODEL=qwen3:8b
#                     export EMBED_MODEL=bge-m3   （ollama pull bge-m3）
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", os.getenv("DASHSCOPE_API_KEY", ""))
CHAT_MODEL = os.getenv("QWEN_MODEL", "qwen-turbo")
EMBED_MODEL = os.getenv("EMBED_MODEL", "text-embedding-v3")
CHAT_URL = f"{LLM_BASE_URL}/chat/completions"
EMBED_URL = f"{LLM_BASE_URL}/embeddings"
ALLOWED_EXT = {".txt", ".md", ".pdf"}
# 公网部署必配：设置后所有 /api/* 请求需携带 X-Access-Token 头（或 ?token= 前端自动转发）
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN", "")


def require_token(x_token: str | None = Header(default=None, alias="X-Access-Token")):
    if ACCESS_TOKEN and x_token != ACCESS_TOKEN:
        raise HTTPException(401, "缺少或错误的访问令牌（联系管理员获取）")

app = FastAPI(title="Qwen3 RAG Demo API")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

kb = VectorStore()
kb.load()


# ---------------- 基础工具 ----------------
async def embed_texts(texts: list[str]) -> list[list[float]]:
    """批量向量化（百炼单次最多 10 条，分批调用）。"""
    out: list[list[float]] = []
    async with httpx.AsyncClient(timeout=60) as client:
        for i in range(0, len(texts), 10):
            r = await client.post(
                EMBED_URL,
                headers={"Authorization": f"Bearer {LLM_API_KEY}"},
                json={"model": EMBED_MODEL, "input": texts[i : i + 10]},
            )
            if r.status_code != 200:
                raise HTTPException(502, f"向量化失败: {r.text[:300]}")
            items = r.json()["data"]
            out += [item["embedding"] for item in sorted(items, key=lambda x: x["index"])]
    return out


def extract_pdf(data: bytes) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        raise HTTPException(500, "服务器未安装 pypdf（pip install pypdf）")
    reader = PdfReader(io.BytesIO(data))
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def extract_text(filename: str, data: bytes) -> str:
    ext = os.path.splitext(filename)[1].lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, f"仅支持 {'/'.join(ALLOWED_EXT)} 格式")
    if ext == ".pdf":
        return extract_pdf(data)
    return data.decode("utf-8", errors="ignore")


# ---------------- 接口 ----------------
class ChatMessage(BaseModel):
    role: str = Field(pattern="^(system|user|assistant)$")
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]
    max_tokens: int = 1024


@app.get("/api/health")
def health():
    return {"status": "ok", "model": CHAT_MODEL, "kb_chunks": kb.count}


@app.post("/api/upload")
async def upload(file: UploadFile, _=Depends(require_token)):
    if not LLM_API_KEY:
        raise HTTPException(500, "服务端未配置 LLM_API_KEY（云端模式）或 LLM_BASE_URL（本地模式）")
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(400, "文件超过 10MB 限制")

    text = extract_text(file.filename, data)
    if len(text.strip()) < 10:
        raise HTTPException(400, "未能提取到有效文本内容")

    chunks = chunk_text(text)
    vectors = await embed_texts(chunks)
    n = kb.add(file.filename, chunks, vectors)
    return {"doc": file.filename, "chunks": n, "kb_total_chunks": kb.count}


@app.get("/api/kb")
def kb_status():
    docs = {}
    for m in kb.meta:
        d = docs.setdefault(m["doc_id"], {"name": m["name"], "chunks": 0})
        d["chunks"] += 1
    return {"total_chunks": kb.count, "docs": list(docs.values())}


@app.delete("/api/kb")
def kb_clear():
    kb.clear()
    return {"status": "cleared"}


@app.get("/api/debug")
async def debug_search(q: str, token: str = ""):
    """调试接口：查看某问题的检索命中片段（浏览器访问 /api/debug?q=问题&token=令牌）"""
    if ACCESS_TOKEN and token != ACCESS_TOKEN:
        raise HTTPException(401, "令牌错误")
    if kb.count == 0:
        return {"q": q, "kb_chunks": 0, "hits": []}
    q_vec = (await embed_texts([q]))[0]
    hits = kb.search(q_vec, top_k=6)
    return {
        "q": q,
        "kb_chunks": kb.count,
        "hits": [{"score": h["score"], "text": h["text"][:150]} for h in hits],
    }


@app.post("/api/chat")
async def chat(req: ChatRequest, _=Depends(require_token)):
    if not LLM_API_KEY:
        raise HTTPException(500, "服务端未配置 LLM_API_KEY（云端模式）或 LLM_BASE_URL（本地模式）")

    last_user = next((m.content for m in reversed(req.messages) if m.role == "user"), "")
    if not last_user:
        raise HTTPException(400, "缺少用户消息")

    # ---- RAG 检索 ----
    sources, context_block = [], ""
    if kb.count > 0:
        q_vec = (await embed_texts([last_user]))[0]
        hits = kb.search(q_vec, top_k=6)
        if hits:
            refs = "\n\n".join(
                f"[{i + 1}] （来源：{h['name']}）\n{h['text']}"
                for i, h in enumerate(hits)
            )
            context_block = (
                f"以下是知识库中检索到的参考资料：\n\n{refs}\n\n"
                "回答要求（必须严格遵守）：\n"
                "1. 只能依据参考资料回答具体问题；若参考资料中找不到答案，"
                "必须第一句就说明「知识库中没有相关内容」，不得编造数字或事实；\n"
                "2. 依据资料回答时，在对应内容后标注引用序号，如 [1]；\n"
                "3. 参考资料与问题无关时，忽略资料，不要引用。"
            )
            sources = [
                {"idx": i + 1, "name": h["name"], "score": h["score"],
                 "snippet": h["text"][:120] + ("…" if len(h["text"]) > 120 else "")}
                for i, h in enumerate(hits)
            ]

    system_prompt = (
        "你是企业智能助手「小千」，回答简洁、专业、友好。"
        + (("\n\n" + context_block) if context_block else "")
    )

    payload = {
        "model": CHAT_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            *[m.model_dump() for m in req.messages],
        ],
        "max_tokens": req.max_tokens,
        "stream": True,
        "enable_thinking": False,
    }
    headers = {"Authorization": f"Bearer {LLM_API_KEY}"}

    async def event_stream():
        async with httpx.AsyncClient(timeout=120) as client:
            async with client.stream("POST", CHAT_URL, json=payload, headers=headers) as r:
                if r.status_code != 200:
                    body = (await r.aread()).decode("utf-8", "ignore")
                    yield f"data: {json.dumps({'error': body})}\n\n"
                    return
                async for line in r.aiter_lines():
                    if line.startswith("data:"):
                        chunk = line[5:].strip()
                        if chunk == "[DONE]":
                            break
                        try:
                            delta = json.loads(chunk)["choices"][0]["delta"].get("content", "")
                        except Exception:
                            continue
                        if delta:
                            yield f"data: {json.dumps({'content': delta}, ensure_ascii=False)}\n\n"
        if sources:
            yield f"data: {json.dumps({'sources': sources}, ensure_ascii=False)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
